package com.example.location

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
